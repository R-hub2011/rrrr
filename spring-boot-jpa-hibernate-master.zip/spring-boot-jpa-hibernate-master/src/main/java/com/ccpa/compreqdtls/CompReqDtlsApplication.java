package com.ccpa.compreqdtls;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompReqDtlsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompReqDtlsApplication.class, args);
	}

}
