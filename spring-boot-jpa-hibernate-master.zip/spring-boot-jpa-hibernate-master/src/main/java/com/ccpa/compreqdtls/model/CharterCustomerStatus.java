package com.ccpa.compreqdtls.model;

public enum CharterCustomerStatus {
    ACTIVE,
    FORMER,
    NEVER,ResiCSC;
}
