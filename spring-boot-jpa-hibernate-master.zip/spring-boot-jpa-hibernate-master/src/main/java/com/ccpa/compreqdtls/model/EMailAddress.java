package com.ccpa.compreqdtls.model;

public class EMailAddress {
	private String emailAddress;

	public EMailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public EMailAddress() {
		// TODO Auto-generated constructor stub
	}

	public String getEmailAddress() {
		return emailAddress;
	}

}
