package com.ccpa.compreqdtls.model;

public enum PassFail {
	FAIL,
	PASS,ResiKPF;
}
